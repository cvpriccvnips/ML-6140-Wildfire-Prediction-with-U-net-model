#!/usr/bin/env python
# Exposes CLI tool as a package when installing via setup.py
